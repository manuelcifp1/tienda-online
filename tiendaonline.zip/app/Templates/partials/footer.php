<!-- Footer básico -->
<footer>
    <p>&copy; <?= date('Y') ?> Tienda Online</p>
</footer>
