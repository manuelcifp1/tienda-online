<!-- Vista principal -->
<h1><?= htmlspecialchars($titulo) ?></h1>
<p>Comics Manolo, tu tienda online</p>
