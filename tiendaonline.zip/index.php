<?php
// Redirección automática a /public/
header("Location: /tienda-online/public/");
exit;
